const {test}=require('node:test'),assert=require('node:assert/strict'),{once}=require('node:events');const {createBridge}=require('./bridge.cjs');
test('origin filtering, pairing, authenticated telemetry, expiry and retry limits',async()=>{
 let now=100;const origin='http://127.0.0.1:8771';const {server,code}=createBridge({port:18772,siteURL:origin,now:()=>now,getState:()=>({connected:true,game:1,x:123,z:456,region:{name:'Paris',country:'FR',x:123,z:456}})});
 server.listen(18772,'127.0.0.1');await once(server,'listening');
 const request=(route,options={})=>fetch('http://127.0.0.1:18772'+route,options);
 const pair=c=>request('/api/pair',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({code:c})});
 try{
 const page=await (await request('/')).text();const nonce=page.match(/name="nonce" value="([a-f0-9]+)"/)[1];
 const approve=(o,n)=>request('/approve',{method:'POST',redirect:'manual',headers:{Origin:o,'Content-Type':'application/x-www-form-urlencoded'},body:'nonce='+n});
 assert.equal((await approve(origin,nonce)).status,403);
 assert.equal((await approve('http://127.0.0.1:18772','bad')).status,403);
 const approved=await approve('http://127.0.0.1:18772',nonce);assert.equal(approved.status,303);
 const destination=new URL(approved.headers.get('location'));assert.equal(destination.origin,origin);assert.equal(destination.search,'');
 const approvedToken=new URLSearchParams(destination.hash.slice(1)).get('wwreutr-token');
 assert.equal((await request('/api/telemetry',{headers:{Origin:origin,Authorization:'Bearer '+approvedToken}})).status,200);

  assert.equal((await request('/api/telemetry',{headers:{Origin:origin}})).status,401);
  assert.equal((await request('/api/status',{headers:{Origin:'https://untrusted.example'}})).status,403);
  const pre=await request('/api/telemetry',{method:'OPTIONS',headers:{Origin:origin,'Access-Control-Request-Private-Network':'true'}});assert.equal(pre.status,204);assert.equal(pre.headers.get('access-control-allow-origin'),origin);assert.equal(pre.headers.get('access-control-allow-private-network'),'true');
  const paired=await pair(code);assert.equal(paired.status,200);const {token}=await paired.json();assert.match(token,/^[a-f0-9]{64}$/);
  const telemetry=await request('/api/telemetry',{headers:{Origin:origin,Authorization:'Bearer '+token}});assert.equal(telemetry.status,200);const body=await telemetry.json();assert.equal(body.region.country,'FR');assert.equal(body.x,undefined);assert.equal(body.region.x,undefined);
  assert.equal((await request('/api/telemetry',{headers:{Origin:'http://127.0.0.1:18772',Authorization:'Bearer '+token}})).status,401);
  now+=86400001;assert.equal((await request('/api/telemetry',{headers:{Origin:origin,Authorization:'Bearer '+token}})).status,401);
  for(let i=0;i<5;i++)assert.equal((await pair('invalid')).status,401);
  assert.equal((await pair(code)).status,429);
  now+=60001;assert.equal((await pair(code)).status,200);
 }finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
});
