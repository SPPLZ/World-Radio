const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
class RegionTracker {
  constructor(cities,{settleMs=8000,margin=0.15,maxDistance=16000}={}) {Object.assign(this,{cities,settleMs,margin,maxDistance});this.current=null;this.pending=null;}
  update(sample,now=Date.now()) {
    if(!sample.connected||sample.paused||sample.game!==1||!Number.isFinite(sample.x)||!Number.isFinite(sample.z)) {this.pending=null;return {region:this.current,changed:false};}
    const ranked=this.cities.map(c=>({...c,distance:distance(sample,c)})).sort((a,b)=>a.distance-b.distance);
    const best=ranked[0];
    if(!best||best.distance>this.maxDistance){this.pending=null;return {region:this.current,changed:false,outOfRange:true};}
    const old=ranked.find(c=>c.country===this.current?.country);
    if(this.current&&best.country!==this.current.country&&old&&best.distance>old.distance*(1-this.margin)){this.pending=null;return {region:this.current,changed:false};}
    if(best.country===this.current?.country){this.current=best;this.pending=null;return {region:best,changed:false};}
    if(this.pending?.country!==best.country)this.pending={country:best.country,since:now};
    if(now-this.pending.since<this.settleMs)return {region:this.current,changed:false,candidate:best};
    this.current=best;this.pending=null;return {region:best,changed:true};
  }
}
module.exports={RegionTracker};
