param([string]$GamePath = 'C:\Program Files (x86)\Steam\steamapps\common\Euro Truck Simulator 2')
$ErrorActionPreference = 'Stop'
if (Get-Process eurotrucks2 -ErrorAction SilentlyContinue) { throw 'Close Euro Truck Simulator 2 before installing the plugin.' }
$radioGameRoot = (Resolve-Path -LiteralPath $GamePath).Path
if (-not (Test-Path -LiteralPath (Join-Path $radioGameRoot 'bin\win_x64\eurotrucks2.exe'))) { throw 'ETS2 game executable not found.' }
$radioPluginDir = Join-Path $radioGameRoot 'bin\win_x64\plugins'
$radioSource = Join-Path $PSScriptRoot 'vendor\local-radio.dll'
$radioManifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'vendor\source.json') -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $radioSource -Algorithm SHA256).Hash.ToLower() -ne $radioManifest.dllSha256) { throw 'Plugin checksum mismatch.' }
New-Item -ItemType Directory -Force -Path $radioPluginDir | Out-Null
$radioDestination = Join-Path $radioPluginDir 'local-radio.dll'
if (Test-Path -LiteralPath $radioDestination) {
    if ((Get-FileHash -LiteralPath $radioDestination -Algorithm SHA256).Hash.ToLower() -eq $radioManifest.dllSha256) { Write-Output 'The same plugin is already installed.'; exit }
    throw 'A different local-radio.dll already exists. It was not overwritten.'
}
Copy-Item -LiteralPath $radioSource -Destination $radioDestination
Write-Output 'Installed. Restart ETS2 and accept its SDK notice, then launch WWR-ETS2.cmd.'
