$ErrorActionPreference = 'Stop'
$testName = 'Local\WWR-Test-' + [guid]::NewGuid().ToString('N')
$testMap = [IO.MemoryMappedFiles.MemoryMappedFile]::CreateNew($testName,32768)
$testView = $testMap.CreateViewAccessor()
try {
    $testView.Write(0,[bool]$true)
    $testView.Write(4,[bool]$false)
    $testView.Write(8,[uint64]123456)
    $testView.Write(40,[uint32]12)
    $testView.Write(52,[uint32]1)
    $testView.Write(2200,[double]12345.5)
    $testView.Write(2216,[double]-6789.25)
    $data = & (Join-Path $PSScriptRoot 'read-telemetry.ps1') -MapName $testName -SampleLimit 1 | ConvertFrom-Json
    if (-not $data.connected -or $data.x -ne 12345.5 -or $data.z -ne -6789.25 -or $data.game -ne 1) { throw 'Telemetry offsets mismatch' }
    $testView.Write(40,[uint32]99)
    $data = & (Join-Path $PSScriptRoot 'read-telemetry.ps1') -MapName $testName -SampleLimit 1 | ConvertFrom-Json
    if ($data.connected) { throw 'Unsupported ABI was accepted' }
    Write-Output 'PASS: isolated shared-memory reader coordinates, game ID and ABI rejection'
} finally { $testView.Dispose(); $testMap.Dispose() }
